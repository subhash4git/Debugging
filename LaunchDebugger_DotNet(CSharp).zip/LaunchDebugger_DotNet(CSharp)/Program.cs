﻿// Author - Subhash.M <subhash4git@gmail.com> , Git -> subhash4git
// For any support regarding debugging or following code snippet.
// Follow my debugging related GIT repository.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaunchDebugger_DotNet_CSharp_
{
    class Program
    {
        static void Main(string[] args)
        {
            // The following code will be executed only in debug mode.
            // The logic will attach a debugger to the process for helping your debugging.
            #if DEBUG
              System.Diagnostics.Debugger.Launch();
            #endif

            Console.WriteLine("Hey , You started debugging...! , Go Ahead. Happy Debugging.");
            Console.ReadKey();
        }
    }
}
